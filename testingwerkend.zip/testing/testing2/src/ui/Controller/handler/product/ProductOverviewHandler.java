package ui.Controller.handler.product;

import domain.db.DbException;
import domain.model.NotAuthorizedException;
import domain.model.Product;
import domain.model.Role;
import domain.service.ShopService;
import ui.controller.handler.HandlerFactory;
import ui.controller.handler.RequestHandler;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class ProductOverviewHandler extends RequestHandler {

	public ProductOverviewHandler(ShopService shopService, HandlerFactory handlerFactory) {
		super(shopService, handlerFactory);
	}

	@Override
	public void handleRequest(HttpServletRequest request, HttpServletResponse response) throws NotAuthorizedException, ServletException, IOException {
		Role[] roles = {Role.ADMINISTRATOR, Role.CUSTOMER};
		checkRole(request, roles);
		
		List<Product> products;
		try {
			products = this.shopService.getProducts();
			request.setAttribute("products", products);
			RequestDispatcher view = request.getRequestDispatcher("productOverview.jsp");
			view.forward(request, response);
		} catch (DbException e) {
			Map<String, String> errors = new HashMap<String, String>();
			errors.put("ShopService getProducts() error", e.getMessage());
			request.setAttribute("errors", errors);
		}	
	}
	
}
