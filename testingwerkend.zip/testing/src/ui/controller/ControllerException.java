package ui.controller;

public class ControllerException extends Exception {

    static final long serialVersionUID = 1L;

    public ControllerException(String message) {
        super(message);
    }

}